/* =========================================================================
   NOTICE SYSTEM (Tag Manager) — HYBRID: each notification picks its own style
   ---------------------------------------------------------------------
   Two kinds of messages exist in the app:
     - NOTICES (sticky state): TM.notice.show(id, opts) / hide(id) / has(id)
       e.g. "You have unsaved changes", "Auto-Do modified ..."
     - ALERTS (one-shot messages): window.showAlert(text, type, duration)
       e.g. "Saved 3 file(s).", errors, warnings

   DISPLAY STYLES (for every notification, individually):
     Default    follows the global style chosen in ⚙️ > 🔔 Notifications
     Permanent  row in the bar above the workspace (stays until dismissed)
     Temporary  small toast at the bottom, one at a time (queue)
     Both       bar row + toast
     Hidden     not shown at all

   MANAGER (⚙️ > 🔔 Notifications > 📋 Manage notifications…)
     A popout lists every notification the app has shown so far (learned
     automatically while you work) and lets you set the style of each one.
     Alerts that only differ by numbers or quoted names ("Saved 3 file(s)",
     "Saved 5 file(s)", Tag "x" accepted…) are the SAME entry.
     Search, filter (customized / alerts / sticky notices), bulk apply,
     ▶ replay a sample, ✕ forget an entry, reset everything to Default.

   BAR (permanent rows)
     - Alerts sit below the sticky notices, newest first, identical ones are
       merged ("×3"), each has ×; "Clear all" appears with 2+ alerts.
     - "Visible lines": rows shown before the bar gets its own scroll.
   TOAST (temporary)
     - One at a time, "Seconds per notification" each, then the next one by
       itself; click the toast to skip. A sticky notice is shown once per
       change (not repeated); hide(id) removes it from the queue.
     - The duration setting is used for every toast (the optional `duration`
       argument of showAlert is ignored).

   Settings saved: 'notice-mode' (global default style), 'notice-max-lines',
   'notice-seconds', 'notice-rules' (per-notification styles + learned list).

   API (compatible with the old one):
     TM.notice.show(id, { text | html, theme, icon, order, dismissible, onDismiss })
         theme: 'warn' | 'success' | 'error' | 'info'; order: lower = higher in the bar
     TM.notice.hide(id) / TM.notice.has(id)
     TM.notice.getMode() / setMode('permanent' | 'temporary')   (global default)
     TM.notice.getRule(key) / setRule(key, 'default'|'permanent'|'temporary'|'both'|'off')
     TM.notice.openManager()

   window.showAlert is replaced here (loads after tagmanager_alert.js, which
   can stay loaded). Default alert type when none is given: 'success'.
   Must load after tagmanager_tm.js.
========================================================================= */

(function () {
    const TM = window.TM = window.TM || {};
    if (TM.notice && TM.notice.__hybrid) return;

    const THEMES = {
        warn:    { accent: '#ffd040', bg: '#101723', icon: '⚠️' },
        success: { accent: '#00ff99', bg: '#0d1f16', icon: '⚡' },
        error:   { accent: '#ff6060', bg: '#2a0000', icon: '❌' },
        info:    { accent: '#66ccff', bg: '#001a2a', icon: 'ℹ️' }
    };
    const ALERT_ICONS = { success: '✅', error: '❌', warn: '⚠️', info: 'ℹ️' };
    const KEYS = { mode: 'notice-mode', lines: 'notice-max-lines', secs: 'notice-seconds', rules: 'notice-rules' };
    const DEFAULTS = { mode: 'permanent', lines: 3, seconds: 5 };
    const RULE_MODES = ['permanent', 'temporary', 'both', 'off'];
    const MODE_LABELS = { permanent: 'Permanent bar', temporary: 'Temporary toast', both: 'Bar + toast', off: 'Hidden' };
    const ALERT_ORDER_BASE = 100000;   // alert rows sit below the notices (order 0..99), newest first
    const MAX_ALERT_ROWS = 30;
    const MAX_RULES = 300;
    const GAP = 8;

    const cfg = { mode: DEFAULTS.mode, lines: DEFAULTS.lines, seconds: DEFAULTS.seconds };
    const sticky = new Map();          // id -> { opts, sig, shown }
    let rules = {};                    // ruleKey -> { m, s, t, k, n, ts }
    let alertSeq = 0;
    let rulesTimer = null;

    const esc = v => (typeof window.escHTML === 'function'
        ? window.escHTML(v)
        : String(v == null ? '' : v).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])));
    const clampNum = (v, lo, hi, fb) => { v = parseFloat(v); return isFinite(v) ? Math.min(hi, Math.max(lo, v)) : fb; };

    function normType(t) {
        if (!t) return 'success';
        t = String(t).toLowerCase();
        if (t === 'warning') return 'warn';
        return THEMES[t] ? t : 'info';
    }

    /* ---------- RULES: which style does each notification use ---------- */
    const wantsBar = m => m === 'permanent' || m === 'both';
    const wantsToast = m => m === 'temporary' || m === 'both';
    function effective(ruleKey) {
        const r = rules[ruleKey];
        return (r && RULE_MODES.includes(r.m)) ? r.m : cfg.mode;
    }

    // "Saved 3 file(s)" and "Saved 5 file(s)" are the same notification: digits and quoted names are wildcards.
    function patternOf(text) {
        return String(text).replace(/\s+/g, ' ').trim()
            .replace(/"[^"]*"/g, '"…"').replace(/“[^”]*”/g, '"…"')
            .replace(/\d+(?:[.,]\d+)?/g, '#').slice(0, 140);
    }
    const alertKey = (type, text) => type + '|' + patternOf(text);
    const noticeKey = id => 'n|' + id;
    const plain = html => String(html == null ? '' : html).replace(/<[^>]*>/g, ' ').replace(/&nbsp;/g, ' ').replace(/\s+/g, ' ').trim();

    function scheduleSaveRules() {
        clearTimeout(rulesTimer);
        rulesTimer = setTimeout(() => {
            rulesTimer = null;
            if (typeof window.saveSetting === 'function') window.saveSetting(KEYS.rules, rules);
        }, 1000);
    }

    function pruneRules() {
        const keys = Object.keys(rules);
        if (keys.length <= MAX_RULES) return;
        keys.filter(k => !RULE_MODES.includes(rules[k].m)).sort((a, b) => (rules[a].ts || 0) - (rules[b].ts || 0))
            .slice(0, keys.length - MAX_RULES).forEach(k => { delete rules[k]; });
    }

    function learn(key, sample, type, kind) {
        let r = rules[key];
        if (!r) { r = rules[key] = { m: 'default', s: '', t: type, k: kind, n: 0, ts: 0 }; pruneRules(); }
        r.s = String(sample).slice(0, 160);
        r.t = type;
        r.k = kind;
        r.n = (r.n || 0) + 1;
        r.ts = Date.now();
        scheduleSaveRules();
    }

    /* ---------- STYLES ---------- */
    const style = document.createElement('style');
    style.textContent = `
        #tm-notice-stack { display: flex; flex-direction: column; gap: ${GAP}px; margin: 12px 20px 0 20px; flex-shrink: 0; }
        #tm-notice-stack:empty { display: none; }
        .tm-notice { position: relative; padding: 10px 14px; color: #f5f5f5; border-radius: 7px; font-size: 13.5px; line-height: 1.45; text-align: center; box-sizing: border-box; border-left: 3px solid var(--tm-notice-accent); border-right: 3px solid var(--tm-notice-accent); background: var(--tm-notice-bg); flex-shrink: 0; }
        .tm-notice-icon { color: var(--tm-notice-accent); margin: 0 6px; font-size: 14px; line-height: 1; }
        .tm-notice-close { position: absolute; right: 10px; top: 50%; transform: translateY(-50%); background: transparent; border: none; color: var(--tm-notice-accent); font-size: 16px; font-weight: bold; cursor: pointer; padding: 0 6px; line-height: 1; }
        .tm-notice-count { margin-left: 8px; font-size: 11px; font-weight: bold; color: var(--tm-notice-accent); }
        #tm-notice-tools { position: sticky; top: 0; z-index: 2; order: -1000; display: flex; justify-content: flex-end; align-items: center; gap: 10px; font-size: 11px; color: #888; background: #111; padding: 2px 0; flex-shrink: 0; }
        #tm-notice-tools button { background: #1b1b1b; color: #aaa; border: 1px solid #333; border-radius: 5px; padding: 3px 9px; font-size: 11px; font-weight: bold; cursor: pointer; }
        #tm-notice-tools button:hover { background: #4a1118; color: #ffb6c0; border-color: #7a222c; }
        #alertBar { cursor: pointer; }
        #alertBar .tm-toast-more { opacity: 0.7; font-size: 10px; margin-left: 6px; }
        #settings-notice-group { display: flex; flex-direction: column; gap: 10px; }
        #settings-notice-group select { max-width: 150px; }

        #modal-notice-rules .tool-modal { width: 760px; max-width: 94vw; max-height: 88vh; }
        #nm-desc { font-size: 11px; color: #888; line-height: 1.5; }
        .nm-bar { display: flex; gap: 6px; align-items: center; flex-wrap: wrap; }
        .nm-bar input[type=text] { flex: 1 1 160px; min-width: 0; }
        .nm-bar select { font-size: 12px; max-width: 170px; }
        .nm-btn { background: #151515; border: 1px solid #444; color: #bbb; border-radius: 5px; padding: 6px 10px; font-size: 11px; font-weight: bold; cursor: pointer; white-space: nowrap; }
        .nm-btn:hover { color: #fff; border-color: #888; background: #222; }
        .nm-btn.danger:hover { background: #4a1118; color: #ffb6c0; border-color: #7a222c; }
        #nm-list { max-height: 50vh; overflow-y: auto; display: flex; flex-direction: column; gap: 4px; background: #111; border: 1px solid #333; border-radius: 6px; padding: 6px; }
        .nm-row { display: flex; align-items: center; gap: 8px; background: #151515; border: 1px solid #2a2a2a; border-left: 3px solid var(--nm-accent, #444); border-radius: 6px; padding: 6px 8px; }
        .nm-row.custom { background: #101a14; border-color: #1f4a30; border-left-color: var(--nm-accent, #00aa66); }
        .nm-ico { flex-shrink: 0; width: 20px; text-align: center; }
        .nm-txt { flex: 1; min-width: 0; }
        .nm-sample { font-size: 12px; color: #ddd; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
        .nm-meta { font-size: 10px; color: #777; margin-top: 2px; }
        .nm-meta .nm-tag { color: #b890ff; font-weight: bold; }
        .nm-row select { flex-shrink: 0; width: 175px; font-size: 11px; padding: 4px 6px; }
        .nm-icon-btn { flex-shrink: 0; background: transparent; border: 1px solid #333; color: #888; border-radius: 4px; padding: 3px 7px; font-size: 11px; cursor: pointer; }
        .nm-icon-btn:hover { color: #fff; border-color: #888; }
        .nm-icon-btn.del:hover { color: #ff6060; border-color: #7a222c; }
        .nm-empty { color: #555; font-size: 12px; text-align: center; padding: 22px 10px; }
    `;
    document.head.appendChild(style);

    /* =====================================================================
       BAR (rows in the stack)
    ===================================================================== */
    function getStack() {
        let stack = document.getElementById('tm-notice-stack');
        if (stack) return stack;
        stack = document.createElement('div');
        stack.id = 'tm-notice-stack';
        const workspace = document.getElementById('workspace');
        if (workspace && workspace.parentNode) workspace.parentNode.insertBefore(stack, workspace);
        else document.body.appendChild(stack);
        return stack;
    }

    const rowsOf = stack => Array.from(stack.querySelectorAll(':scope > .tm-notice'));
    const alertRows = stack => rowsOf(stack).filter(e => e.dataset.kind === 'alert');

    function applyTheme(el, theme, order) {
        el.style.setProperty('--tm-notice-accent', theme.accent);
        el.style.setProperty('--tm-notice-bg', theme.bg);
        el.style.order = Number.isFinite(order) ? order : 0;
    }

    function renderRow(id, opts) {
        const theme = THEMES[opts.theme] || THEMES.warn;
        const stack = getStack();
        let el = document.getElementById(id);
        if (!el || el.parentNode !== stack) {
            el = document.createElement('div');
            el.id = id;
            el.className = 'tm-notice';
            stack.appendChild(el);
        }
        el.dataset.kind = 'notice';
        applyTheme(el, theme, opts.order);

        const icon = `<span class="tm-notice-icon">${opts.icon || theme.icon}</span>`;
        const body = opts.html !== undefined ? opts.html : esc(opts.text === undefined ? '' : opts.text);
        el.innerHTML = `${icon}${body}${icon}` + (opts.dismissible ? '<button class="tm-notice-close" title="Dismiss this notice">&times;</button>' : '');

        if (opts.dismissible) {
            el.querySelector('.tm-notice-close').onclick = () => {
                TM.notice.hide(id);
                if (typeof opts.onDismiss === 'function') opts.onDismiss();
            };
        }
        return el;
    }

    function removeRow(id) {
        const el = document.getElementById(id);
        if (el && el.classList.contains('tm-notice')) el.remove();
    }

    function addAlertRow(text, type, rkey) {
        const stack = getStack();
        const theme = THEMES[type];
        const key = type + '|' + text;
        let el = alertRows(stack).find(e => e.dataset.key === key);
        let count = 1;
        if (el) count = (parseInt(el.dataset.count, 10) || 1) + 1;
        else {
            el = document.createElement('div');
            el.className = 'tm-notice';
            el.dataset.kind = 'alert';
            el.dataset.key = key;
            stack.appendChild(el);
        }
        el.dataset.rule = rkey;
        el.dataset.count = String(count);
        applyTheme(el, theme, ALERT_ORDER_BASE - (++alertSeq));   // newest first

        const icon = `<span class="tm-notice-icon">${ALERT_ICONS[type]}</span>`;
        el.innerHTML = `${icon}${esc(text)}${count > 1 ? `<span class="tm-notice-count">×${count}</span>` : ''}${icon}<button class="tm-notice-close" title="Dismiss">&times;</button>`;
        el.querySelector('.tm-notice-close').onclick = () => { el.remove(); updateTools(); layout(); };

        // Bounded list: drop the oldest alerts (highest order).
        const rows = alertRows(stack).sort((a, b) => (+b.style.order) - (+a.style.order));
        while (rows.length > MAX_ALERT_ROWS) rows.shift().remove();

        updateTools();
        layout();
        try { el.scrollIntoView({ block: 'nearest' }); } catch (e) { /* ignore */ }
    }

    // "Clear all" appears only when there are 2+ alert rows.
    function updateTools() {
        const stack = document.getElementById('tm-notice-stack');
        if (!stack) return;
        const n = alertRows(stack).length;
        let tools = stack.querySelector(':scope > #tm-notice-tools');
        if (n < 2) { if (tools) tools.remove(); return; }
        if (!tools) {
            tools = document.createElement('div');
            tools.id = 'tm-notice-tools';
            tools.innerHTML = '<span></span><button title="Dismiss all alert messages (sticky notices stay)">🧹 Clear all</button>';
            tools.querySelector('button').onclick = () => {
                alertRows(stack).forEach(e => e.remove());
                updateTools(); layout();
            };
            stack.insertBefore(tools, stack.firstChild);
        }
        tools.querySelector('span').textContent = `${n} notifications`;
    }

    // Height of the bar = the first N rows (N = "Visible lines"); more rows -> internal scroll.
    function layout() {
        const stack = document.getElementById('tm-notice-stack');
        if (!stack) return;
        const rows = rowsOf(stack).sort((a, b) => (+a.style.order || 0) - (+b.style.order || 0));
        if (rows.length <= cfg.lines) { stack.style.maxHeight = ''; stack.style.overflowY = ''; return; }
        const tools = stack.querySelector(':scope > #tm-notice-tools');
        let h = tools ? tools.offsetHeight + GAP : 0;
        rows.slice(0, cfg.lines).forEach((r, i) => { h += r.offsetHeight + (i ? GAP : 0); });
        stack.style.maxHeight = h + 'px';
        stack.style.overflowY = 'auto';
    }
    window.addEventListener('resize', layout);

    /* =====================================================================
       TOAST (one at a time, queue)
    ===================================================================== */
    const queue = [];          // { id?, key?, rule, type, html, icon }
    let current = null;
    let busy = false;
    let timer = null;

    function getBar() {
        let bar = document.getElementById('alertBar');
        if (!bar) {
            bar = document.createElement('div');
            bar.id = 'alertBar';
            document.body.appendChild(bar);
        }
        if (!bar.__tmToastBound) {
            bar.__tmToastBound = true;
            bar.title = 'Click to skip to the next notification';
            bar.addEventListener('click', () => finishToast());
        }
        return bar;
    }

    const sameItem = (a, b) => (a.id && a.id === b.id) || (!a.id && !b.id && a.key === b.key);

    function updateBadge() {
        const bar = document.getElementById('alertBar');
        const el = bar && bar.querySelector('.tm-toast-more');
        if (el) el.textContent = queue.length ? `(+${queue.length})` : '';
    }

    function paintToast(item) {
        const bar = getBar();
        bar.className = item.type;                 // error / success / warn / info (CSS of #alertBar)
        bar.innerHTML = `${item.icon ? item.icon + ' ' : ''}${item.html}<span class="tm-toast-more"></span>`;
        updateBadge();
    }

    function startTimer() {
        clearTimeout(timer);
        timer = setTimeout(finishToast, Math.round(cfg.seconds * 1000));
    }

    function pump() {
        if (busy || !queue.length) return;
        busy = true;
        current = queue.shift();
        paintToast(current);
        startTimer();
    }

    function finishToast() {
        if (!current) return;
        clearTimeout(timer);
        current = null;
        const bar = document.getElementById('alertBar');
        if (bar) { bar.className = ''; bar.innerHTML = ''; }
        setTimeout(() => { busy = false; pump(); }, 150);   // short gap so the change is noticeable
    }

    function enqueueToast(item) {
        if (current && sameItem(current, item)) {          // same message already on screen: refresh it
            current = Object.assign(current, item);
            paintToast(current);
            startTimer();
            return;
        }
        const i = queue.findIndex(q => sameItem(q, item));
        if (i >= 0) { queue[i] = item; updateBadge(); return; }
        queue.push(item);
        updateBadge();
        pump();
    }

    function dropQueuedNotice(id) {
        for (let i = queue.length - 1; i >= 0; i--) if (queue[i].id === id) queue.splice(i, 1);
        if (current && current.id === id) finishToast(); else updateBadge();
    }

    function noticeToast(id, s) {
        const theme = THEMES[s.opts.theme] || THEMES.warn;
        const html = s.opts.html !== undefined ? s.opts.html : esc(s.opts.text === undefined ? '' : s.opts.text);
        return { id, rule: noticeKey(id), type: THEMES[s.opts.theme] ? s.opts.theme : 'warn', html, icon: s.opts.icon || theme.icon };
    }

    /* =====================================================================
       APPLYING THE STYLE OF EACH NOTIFICATION
    ===================================================================== */
    function applySticky(id, s) {
        const eff = effective(noticeKey(id));
        if (wantsBar(eff)) renderRow(id, s.opts); else removeRow(id);
        if (wantsToast(eff)) {
            if (!s.shown) { s.shown = true; enqueueToast(noticeToast(id, s)); }
        } else {
            s.shown = false;
            dropQueuedNotice(id);
        }
    }

    // Re-checks everything after a rule / global style change.
    function reconcile() {
        const stack = document.getElementById('tm-notice-stack');
        if (stack) alertRows(stack).forEach(e => { if (!wantsBar(effective(e.dataset.rule))) e.remove(); });
        for (let i = queue.length - 1; i >= 0; i--) if (!wantsToast(effective(queue[i].rule))) queue.splice(i, 1);
        if (current && !wantsToast(effective(current.rule))) finishToast();
        sticky.forEach((s, id) => applySticky(id, s));
        updateTools();
        layout();
        updateBadge();
    }

    function dispatchAlert(text, type, learnIt) {
        const rkey = alertKey(type, text);
        if (learnIt) learn(rkey, text, type, 'alert');
        const eff = effective(rkey);
        if (wantsBar(eff)) addAlertRow(text, type, rkey);
        if (wantsToast(eff)) enqueueToast({ key: type + '|' + text, rule: rkey, type, html: esc(text), icon: ALERT_ICONS[type] });
    }

    /* =====================================================================
       PUBLIC API
    ===================================================================== */
    TM.notice = {
        __hybrid: true,

        show(id, opts = {}) {
            const sig = JSON.stringify([opts.text, opts.html, opts.theme, opts.icon]);
            const prev = sticky.get(id);
            const s = { opts, sig, shown: !!(prev && prev.sig === sig && prev.shown) };
            sticky.set(id, s);
            learn(noticeKey(id), opts.html !== undefined ? plain(opts.html) : (opts.text || id), THEMES[opts.theme] ? opts.theme : 'warn', 'notice');
            applySticky(id, s);
            layout();
            return document.getElementById(id) || getBar();
        },

        hide(id) {
            sticky.delete(id);
            removeRow(id);
            dropQueuedNotice(id);
            updateTools();
            layout();
        },

        has(id) { return sticky.has(id); },

        getMode() { return cfg.mode; },
        setMode(mode, save) { setGlobalMode(mode, save); },

        getRule(key) { return effective(key); },
        setRule(key, mode, save) { setRule(key, mode, save !== false); },
        openManager() { openManager(); }
    };

    function showAlert(msg, type /*, duration (ignored: the setting rules) */) {
        const text = String(msg == null ? '' : msg);
        if (!text) return;
        dispatchAlert(text, normType(type), true);
    }
    showAlert.__unified = true;
    window.showAlert = showAlert;

    function setGlobalMode(mode, save) {
        cfg.mode = mode === 'temporary' ? 'temporary' : 'permanent';
        // Notices that follow the global style are re-shown in the new one.
        sticky.forEach((s, id) => { if (!RULE_MODES.includes((rules[noticeKey(id)] || {}).m)) s.shown = false; });
        reconcile();
        syncSettingsUI();
        refreshManagerLabels();
        if (save && typeof window.saveSetting === 'function') window.saveSetting(KEYS.mode, cfg.mode);
    }

    function setRule(key, mode, save) {
        const r = rules[key];
        if (!r) return;
        r.m = RULE_MODES.includes(mode) ? mode : 'default';
        if (key.startsWith('n|')) { const s = sticky.get(key.slice(2)); if (s) s.shown = false; }
        reconcile();
        if (save) scheduleSaveRules();
    }

    /* =====================================================================
       MANAGER POPOUT
    ===================================================================== */
    function buildManager() {
        if (document.getElementById('modal-notice-rules')) return;
        const overlay = document.createElement('div');
        overlay.id = 'modal-notice-rules';
        overlay.className = 'modal-overlay';
        overlay.onclick = () => window.closeModal('modal-notice-rules');
        overlay.innerHTML = `
            <div class="tool-modal" onclick="event.stopPropagation()">
                <h3 style="display:flex; justify-content:space-between; align-items:center;">
                    <span>🔔 Manage notifications</span>
                    <button onclick="window.closeModal('modal-notice-rules')" style="background:transparent; border:none; color:#ff4444; font-size:20px; cursor:pointer; font-weight:bold; line-height:1; padding:0;">&times;</button>
                </h3>
                <div id="nm-desc">Every notification the app has shown is listed here (new ones appear as they happen). Choose how each one is displayed: in the <b>permanent bar</b>, as a <b>temporary toast</b>, <b>both</b>, or <b>hidden</b>. <i>Default</i> follows the style set in ⚙️ Settings. Messages that only differ by numbers or quoted names count as one entry.</div>
                <div class="nm-bar">
                    <input type="text" id="nm-search" placeholder="🔍 Filter notifications...">
                    <select id="nm-filter" title="Which entries to list">
                        <option value="all">All</option>
                        <option value="custom">Customized only</option>
                        <option value="alert">Alerts (one-shot)</option>
                        <option value="notice">Sticky notices</option>
                    </select>
                    <button class="nm-btn" id="nm-refresh" title="Reload the list (new notifications may have appeared)">↻</button>
                </div>
                <div class="nm-bar">
                    <span style="font-size:11px; color:#888;">Set all shown to:</span>
                    <select id="nm-bulk"></select>
                    <button class="nm-btn" id="nm-bulk-apply">Apply</button>
                    <span style="flex:1;"></span>
                    <button class="nm-btn" id="nm-reset" title="Every notification goes back to Default">↺ Reset all to Default</button>
                    <button class="nm-btn danger" id="nm-forget" title="Remove the entries that are still on Default from the list (they come back if they appear again)">🗑️ Forget uncustomized</button>
                </div>
                <div id="nm-list"></div>
                <div class="modal-buttons">
                    <button class="btn-cancel" onclick="window.closeModal('modal-notice-rules')">Close</button>
                </div>
            </div>`;
        document.body.appendChild(overlay);

        document.getElementById('nm-search').oninput = renderManager;
        document.getElementById('nm-filter').onchange = renderManager;
        document.getElementById('nm-refresh').onclick = renderManager;
        document.getElementById('nm-bulk-apply').onclick = () => {
            const mode = document.getElementById('nm-bulk').value;
            const keys = visibleEntries();
            if (!keys.length) return;
            keys.forEach(k => { rules[k].m = RULE_MODES.includes(mode) ? mode : 'default'; });
            sticky.forEach(s => { s.shown = false; });
            reconcile(); scheduleSaveRules(); renderManager();
        };
        document.getElementById('nm-reset').onclick = () => {
            if (!confirm('Reset every notification to Default?')) return;
            Object.keys(rules).forEach(k => { rules[k].m = 'default'; });
            sticky.forEach(s => { s.shown = false; });
            reconcile(); scheduleSaveRules(); renderManager();
        };
        document.getElementById('nm-forget').onclick = () => {
            const del = Object.keys(rules).filter(k => !RULE_MODES.includes(rules[k].m));
            if (!del.length) return;
            if (!confirm(`Remove ${del.length} uncustomized entr${del.length === 1 ? 'y' : 'ies'} from the list?`)) return;
            del.forEach(k => { delete rules[k]; });
            scheduleSaveRules(); renderManager();
        };
        document.getElementById('nm-list').addEventListener('change', e => {
            const sel = e.target.closest('.nm-sel');
            if (!sel) return;
            const row = sel.closest('.nm-row');
            setRule(row.dataset.key, sel.value, true);
            row.classList.toggle('custom', RULE_MODES.includes(sel.value));
        });
        document.getElementById('nm-list').addEventListener('click', e => {
            const row = e.target.closest('.nm-row');
            if (!row) return;
            const key = row.dataset.key, r = rules[key];
            if (!r) return;
            if (e.target.closest('.nm-play')) {
                // A sticky notice is previewed as an alert, using the style chosen for the notice.
                const eff = effective(key);
                const type = normType(r.t);
                if (wantsBar(eff)) addAlertRow(r.s, type, key);
                if (wantsToast(eff)) enqueueToast({ key: type + '|' + r.s, rule: key, type, html: esc(r.s), icon: ALERT_ICONS[type] });
            } else if (e.target.closest('.nm-del')) {
                delete rules[key];
                scheduleSaveRules();
                row.remove();
            }
        });
    }

    function modeOptions() {
        return [`<option value="default">Default (${MODE_LABELS[cfg.mode]})</option>`]
            .concat(RULE_MODES.map(m => `<option value="${m}">${MODE_LABELS[m]}</option>`)).join('');
    }

    function visibleEntries() {
        const q = (document.getElementById('nm-search').value || '').trim().toLowerCase();
        const f = document.getElementById('nm-filter').value;
        return Object.keys(rules).filter(k => {
            const r = rules[k];
            if (f === 'custom' && !RULE_MODES.includes(r.m)) return false;
            if (f === 'alert' && r.k !== 'alert') return false;
            if (f === 'notice' && r.k !== 'notice') return false;
            if (q && !(String(r.s).toLowerCase().includes(q) || k.toLowerCase().includes(q))) return false;
            return true;
        }).sort((a, b) => (rules[b].ts || 0) - (rules[a].ts || 0));
    }

    function renderManager() {
        const list = document.getElementById('nm-list');
        if (!list) return;
        document.getElementById('nm-bulk').innerHTML = modeOptions();
        const keys = visibleEntries();
        if (!keys.length) {
            list.innerHTML = `<div class="nm-empty">${Object.keys(rules).length ? 'No notifications match the filter.' : 'No notifications yet — they are listed here as they appear while you use the app.'}</div>`;
            return;
        }
        list.innerHTML = keys.map(k => {
            const r = rules[k];
            const theme = THEMES[r.t] || THEMES.info;
            const isNotice = r.k === 'notice';
            const icon = isNotice ? theme.icon : (ALERT_ICONS[r.t] || 'ℹ️');
            const when = r.ts ? new Date(r.ts).toLocaleString('en-US') : '';
            return `<div class="nm-row${RULE_MODES.includes(r.m) ? ' custom' : ''}" data-key="${esc(k)}" style="--nm-accent:${theme.accent};">
                <span class="nm-ico">${icon}</span>
                <div class="nm-txt">
                    <div class="nm-sample" title="${esc(r.s)}">${esc(r.s) || '<i style="color:#666;">(empty)</i>'}</div>
                    <div class="nm-meta">${isNotice ? '<span class="nm-tag">sticky notice</span>' : 'alert'} · ${esc(r.t)} · seen ${r.n || 0}× · last ${esc(when)}</div>
                </div>
                <select class="nm-sel" title="How this notification is displayed">${modeOptions()}</select>
                <button class="nm-icon-btn nm-play" title="Preview ${isNotice ? 'the text' : 'this alert'} with its current style">▶</button>
                <button class="nm-icon-btn del nm-del" title="Forget this entry (it comes back if it appears again; a customized style is lost)">✕</button>
            </div>`;
        }).join('');
        list.querySelectorAll('.nm-row').forEach(row => {
            const m = rules[row.dataset.key].m;
            row.querySelector('.nm-sel').value = RULE_MODES.includes(m) ? m : 'default';
        });
    }

    // The "Default (…)" labels change when the global style changes.
    function refreshManagerLabels() {
        const modal = document.getElementById('modal-notice-rules');
        if (modal && modal.classList.contains('active')) renderManager();
    }

    function openManager() {
        buildManager();
        document.getElementById('nm-search').value = '';
        document.getElementById('nm-filter').value = 'all';
        renderManager();
        window.openModal('modal-notice-rules');
    }

    /* =====================================================================
       ⚙️ SETTINGS UI
    ===================================================================== */
    function syncSettingsUI() {
        const mode = document.getElementById('notice-mode');
        if (!mode) return;
        mode.value = cfg.mode;
        document.getElementById('notice-lines').value = cfg.lines;
        document.getElementById('notice-seconds').value = cfg.seconds;
    }

    function injectSettings() {
        const dd = document.getElementById('settings-dropdown');
        if (!dd || document.getElementById('settings-notice-group')) return;

        const grp = document.createElement('div');
        grp.id = 'settings-notice-group';
        grp.innerHTML = `
            <div class="settings-group-label">🔔 Notifications</div>
            <label title="Style used by every notification that is set to Default in the manager. Permanent: row in a bar above the workspace until dismissed. Temporary: small toast at the bottom, one at a time.">Default style:
                <select id="notice-mode">
                    <option value="permanent">Permanent bar</option>
                    <option value="temporary">Temporary toast</option>
                </select>
            </label>
            <label title="Permanent bar: how many notifications are visible before the bar gets its own scroll.">Bar: visible lines before scroll
                <input type="number" id="notice-lines" min="1" max="10" step="1" style="width: 50px;">
            </label>
            <label title="Temporary toast: how long each notification stays on screen before the next one appears.">Toast: seconds per notification
                <input type="number" id="notice-seconds" min="1" max="30" step="0.5" style="width: 56px;">
            </label>
            <div style="display:flex; gap:5px;">
                <button id="notice-manage" style="background: #2f1a5c; color: #b890ff; border: 1px solid #4a2a8c; font-size: 11px; flex: 1;" title="Choose how each notification is displayed (bar, toast, both or hidden)">📋 Manage notifications…</button>
                <button id="notice-test" style="background: #1a3a5c; color: #4db8ff; border: 1px solid #2a5a8c; font-size: 11px;" title="Show a sample notification with the current settings">🔔 Test</button>
            </div>`;

        const hr = document.createElement('hr');
        hr.style.cssText = 'border: 0; border-top: 1px solid #333; margin: 5px 0;';

        const backup = Array.from(dd.querySelectorAll('.settings-group-label')).find(e => /Backup/.test(e.textContent));
        if (backup) { dd.insertBefore(grp, backup); dd.insertBefore(hr, backup); }
        else { dd.appendChild(hr); dd.appendChild(grp); }

        document.getElementById('notice-mode').onchange = e => setGlobalMode(e.target.value, true);
        document.getElementById('notice-lines').onchange = e => {
            cfg.lines = Math.round(clampNum(e.target.value, 1, 10, DEFAULTS.lines));
            e.target.value = cfg.lines;
            if (typeof window.saveSetting === 'function') window.saveSetting(KEYS.lines, cfg.lines);
            layout();
        };
        document.getElementById('notice-seconds').onchange = e => {
            cfg.seconds = clampNum(e.target.value, 1, 30, DEFAULTS.seconds);
            e.target.value = cfg.seconds;
            if (typeof window.saveSetting === 'function') window.saveSetting(KEYS.secs, cfg.seconds);
            if (current) startTimer();
        };
        document.getElementById('notice-manage').onclick = () => {
            dd.classList.remove('open');
            openManager();
        };
        document.getElementById('notice-test').onclick = () => {
            window.showAlert('Test notification: this is how messages look with the current settings.', 'info');
        };
        syncSettingsUI();
    }

    async function loadSettings() {
        if (typeof window.getSetting !== 'function') return;
        try {
            const m = await window.getSetting(KEYS.mode, DEFAULTS.mode);
            cfg.lines = Math.round(clampNum(await window.getSetting(KEYS.lines, DEFAULTS.lines), 1, 10, DEFAULTS.lines));
            cfg.seconds = clampNum(await window.getSetting(KEYS.secs, DEFAULTS.seconds), 1, 30, DEFAULTS.seconds);
            const stored = await window.getSetting(KEYS.rules, {});
            // Merge: saved styles win; what was learned before the load only adds counts / newer samples.
            const merged = (stored && typeof stored === 'object') ? stored : {};
            Object.keys(rules).forEach(k => {
                const mem = rules[k], old = merged[k];
                merged[k] = old ? Object.assign({}, old, { s: mem.s, t: mem.t, k: mem.k, n: (old.n || 0) + (mem.n || 0), ts: mem.ts }) : mem;
            });
            rules = merged;
            cfg.mode = m === 'temporary' ? 'temporary' : 'permanent';
            sticky.forEach(s => { s.shown = false; });
            reconcile();
            scheduleSaveRules();
        } catch (e) { /* defaults */ }
    }

    window.addEventListener('DOMContentLoaded', async () => {
        // tagmanager_alert.js may have been loaded after this file: keep the hybrid showAlert.
        if (!window.showAlert || !window.showAlert.__unified) window.showAlert = showAlert;
        await loadSettings();
        injectSettings();
        setTimeout(injectSettings, 1200);   // in case the settings dropdown is rebuilt late
    });
})();
